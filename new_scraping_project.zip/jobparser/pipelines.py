# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import scrapy
from pymongo import MongoClient
from itemadapter import ItemAdapter


class JobparserPipeline:
    def __init__(self):
        # TODO: где нужно поставить self.client.close()
        self.client = MongoClient("localhost:27017")
        self.db = self.client["vacancies"]

    def process_item(self, item, spider: scrapy.Spider):
        # Определять новые поля без определения их в вашем классе Item нельзя
        # item['abracadabra'] = 42
        # Так можно удалять
        # del item['name']
        # item.pop("name")
        # TODO:
        # item['salary_min'] = self.parse_salary()
        # print("42")
        # своя коллекция для каждого паука
        self.db[spider.name].insert_one(item)
        # примеры
        # if spider.name:
        #     ...
        # if "somedomain" in spider.allowed_domains:
        #     ...
        # self.db['hhru'].insert_one(item)
        # self.db['hhru'].update_one(...)

        # print()
        return item

    def parse_salary(self, salary):
        pass
